Name: Yu Gan
Student ID: 4158733480
g++ -o server server.cpp -lnsl -lresolv
g++ -o client client.cpp -lnsl –lresolv

Cited from https://www.geeksforgeeks.org/socket-programming-cc/
