Name: Yu Gan
ID: 4158733480

Achieved: 
The number of input sources is not deterministic in the input file. 

Compile: g++ -std=c++11 tdm.cpp -o tdm
Run: ./tdm input.txt