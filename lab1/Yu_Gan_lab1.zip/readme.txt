Name: Yu Gan
Student ID: 4158733480

Compile:  g++ -std=c++11 distanceVector.cpp -o dv
